# Munna Dhaba & Family Restaurant — Flutter starter

This starter Android app includes a restaurant menu, category filters, dish search, cart quantity controls, checkout-details demo, and a mobile-login placeholder.

## Not yet connected
- Real order submission or admin dashboard
- SMS OTP authentication
- Online payments
- Delivery tracking or live database

Before publishing, confirm the restaurant address, contact number, delivery radius, final menu and prices. Real OTP requires Firebase Authentication or another provider; real ordering needs a secure backend/database.

## Build APK on a computer
1. Install Flutter SDK and Android Studio.
2. Extract this project ZIP and open a terminal in its folder.
3. Run `flutter pub get`.
4. Test with `flutter run` on an emulator or USB-connected Android phone.
5. Run `flutter build apk --release`.
6. APK output: `build/app/outputs/flutter-apk/app-release.apk`.

## If you only have an Android phone
The standard Android Studio build environment generally requires a computer. You can edit the files on your phone, but compile using a trusted cloud build service or a computer. Never upload signing keys or private credentials to an untrusted service.

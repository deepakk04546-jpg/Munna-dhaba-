import 'package:flutter/material.dart';

void main() => runApp(const MunnaDhabaApp());

const forest = Color(0xFF173D2B);
const gold = Color(0xFFE6B85C);
const cream = Color(0xFFFFF9EF);

class MunnaDhabaApp extends StatelessWidget {
  const MunnaDhabaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Munna Dhaba', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: forest), scaffoldBackgroundColor: cream,
      appBarTheme: const AppBarTheme(backgroundColor: forest, foregroundColor: Colors.white)),
    home: const HomePage(),
  );
}

class Food {
  final String name, category, description;
  final int price;
  final IconData icon;
  const Food(this.name, this.category, this.description, this.price, this.icon);
}
const foods = <Food>[
  Food('Veg Thali','Meals','Sabzi, dal, rice and roti',149,Icons.rice_bowl),
  Food('Paneer Butter Masala','Meals','Paneer in creamy tomato gravy',189,Icons.dinner_dining),
  Food('Dal Tadka','Meals','Yellow lentils with aromatic tadka',119,Icons.soup_kitchen),
  Food('Chicken Curry','Non-Veg','Dhaba-style curry with Indian spices',229,Icons.restaurant),
  Food('Chicken Biryani','Non-Veg','Fragrant rice cooked with spices',199,Icons.rice_bowl),
  Food('Masala Chai','Drinks','Indian tea with ginger and spices',25,Icons.local_cafe),
  Food('Cold Drink','Drinks','Chilled soft drink',40,Icons.local_drink),
  Food('Samosa (2 pcs)','Snacks','Crispy pastry with spiced potato filling',30,Icons.bakery_dining),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  String category = 'All', query = '';
  final Map<String,int> cart = {};
  int tab = 0;
  int get totalItems => cart.values.fold(0,(a,b)=>a+b);
  int get totalPrice => foods.fold(0,(sum,f)=>sum+f.price*(cart[f.name]??0));

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Munna Dhaba',style: TextStyle(fontWeight: FontWeight.bold)),Text('& Family Restaurant',style: TextStyle(fontSize: 12,color: gold))]),
      actions: [IconButton(onPressed:()=>setState(()=>tab=1),icon:Badge(isLabelVisible:totalItems>0,label:Text('$totalItems'),child:const Icon(Icons.shopping_bag_outlined))),const SizedBox(width:8)]),
    body: tab==1 ? cartPage() : tab==2 ? profilePage() : menuPage(),
    bottomNavigationBar: NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:const [NavigationDestination(icon:Icon(Icons.restaurant_menu),label:'Menu'),NavigationDestination(icon:Icon(Icons.shopping_cart_outlined),label:'Cart'),NavigationDestination(icon:Icon(Icons.person_outline),label:'Profile')]),
  );

  Widget menuPage() {
    final visible=foods.where((f)=>(category=='All'||f.category==category)&&f.name.toLowerCase().contains(query.toLowerCase())).toList();
    return ListView(padding:const EdgeInsets.all(16),children:[
      Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(gradient:const LinearGradient(colors:[forest,Color(0xFF286044)]),borderRadius:BorderRadius.circular(20)),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('GOOD FOOD, GOOD MOOD',style:TextStyle(color:gold,fontSize:11,letterSpacing:1.5,fontWeight:FontWeight.bold)),SizedBox(height:8),Text('Your favourite dhaba\nfood, delivered fresh.',style:TextStyle(color:Colors.white,fontSize:24,fontWeight:FontWeight.bold)),SizedBox(height:8),Text('Order online • Enjoy at home',style:TextStyle(color:Colors.white70))])),
      const SizedBox(height:18),TextField(onChanged:(v)=>setState(()=>query=v),decoration:InputDecoration(hintText:'Search dishes...',prefixIcon:const Icon(Icons.search),filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide.none))),
      const SizedBox(height:14),SizedBox(height:42,child:ListView(scrollDirection:Axis.horizontal,children:['All','Meals','Non-Veg','Snacks','Drinks'].map((c)=>Padding(padding:const EdgeInsets.only(right:8),child:ChoiceChip(label:Text(c),selected:category==c,onSelected:(_)=>setState(()=>category=c))).toList())),
      const SizedBox(height:10),const Text('Popular on our menu',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold,color:forest)),const SizedBox(height:8),
      if(visible.isEmpty) const Padding(padding:EdgeInsets.all(24),child:Text('No dishes found. Try another search.')),
      ...visible.map(foodCard),
    ]);
  }
  Widget foodCard(Food f) {
    final count=cart[f.name]??0;
    return Card(color:Colors.white,elevation:0,margin:const EdgeInsets.only(bottom:10),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(16),side:const BorderSide(color:Color(0xFFF0E8D9))),child:Padding(padding:const EdgeInsets.all(12),child:Row(children:[
      Container(width:62,height:62,decoration:BoxDecoration(color:const Color(0xFFF7EBD1),borderRadius:BorderRadius.circular(14)),child:Icon(f.icon,color:forest,size:31)),const SizedBox(width:12),
      Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(f.name,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:15)),Text(f.description,maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Colors.black54,fontSize:12)),const SizedBox(height:5),Text('₹${f.price}',style:const TextStyle(color:forest,fontWeight:FontWeight.bold,fontSize:16))])),const SizedBox(width:6),
      count==0?FilledButton(onPressed:()=>setState(()=>cart[f.name]=1),child:const Text('ADD')):Container(decoration:BoxDecoration(color:forest,borderRadius:BorderRadius.circular(10)),child:Row(mainAxisSize:MainAxisSize.min,children:[IconButton(visualDensity:VisualDensity.compact,onPressed:()=>setState(()=>count<=1?cart.remove(f.name):cart[f.name]=count-1),icon:const Icon(Icons.remove,color:Colors.white)),Text('$count',style:const TextStyle(color:Colors.white,fontWeight:FontWeight.bold)),IconButton(visualDensity:VisualDensity.compact,onPressed:()=>setState(()=>cart[f.name]=count+1),icon:const Icon(Icons.add,color:Colors.white))]))
    ])));
  }
  Widget cartPage() {
    final items=foods.where((f)=>(cart[f.name]??0)>0).toList();
    return ListView(padding:const EdgeInsets.all(16),children:[const Text('Your Cart',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold,color:forest)),const SizedBox(height:12),
      if(items.isEmpty) const Padding(padding:EdgeInsets.symmetric(vertical:50),child:Column(children:[Icon(Icons.shopping_bag_outlined,size:64,color:Colors.black26),SizedBox(height:12),Text('Your cart is empty'),Text('Add food from the menu.')])),
      ...items.map((f)=>ListTile(contentPadding:EdgeInsets.zero,leading:CircleAvatar(backgroundColor:const Color(0xFFF7EBD1),child:Icon(f.icon,color:forest)),title:Text(f.name,style:const TextStyle(fontWeight:FontWeight.w600)),subtitle:Text('₹${f.price} × ${cart[f.name]}'),trailing:Text('₹${f.price*cart[f.name]!}',style:const TextStyle(fontWeight:FontWeight.bold)))),
      if(items.isNotEmpty)...[const Divider(height:28),Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('Subtotal',style:TextStyle(fontSize:17)),Text('₹$totalPrice',style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold,color:forest))]),const SizedBox(height:16),FilledButton.icon(onPressed:checkout,icon:const Icon(Icons.check_circle_outline),label:const Padding(padding:EdgeInsets.all(14),child:Text('Continue to Checkout'))),const SizedBox(height:8),const Text('Demo only: real order submission and payment are not connected.',textAlign:TextAlign.center,style:TextStyle(fontSize:12,color:Colors.black54))]
    ]);
  }
  void checkout() {
    final phone=TextEditingController(), address=TextEditingController();
    showModalBottomSheet(context:context,isScrollControlled:true,showDragHandle:true,builder:(ctx)=>Padding(padding:EdgeInsets.fromLTRB(20,8,20,MediaQuery.of(ctx).viewInsets.bottom+24),child:SingleChildScrollView(child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,mainAxisSize:MainAxisSize.min,children:[const Text('Delivery details',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),const SizedBox(height:12),TextField(controller:phone,keyboardType:TextInputType.phone,maxLength:10,decoration:const InputDecoration(labelText:'Mobile number',prefixIcon:Icon(Icons.phone))),TextField(controller:address,maxLines:2,decoration:const InputDecoration(labelText:'Delivery address',prefixIcon:Icon(Icons.location_on_outlined))),const SizedBox(height:8),FilledButton(onPressed:(){if(phone.text.trim().length!=10||address.text.trim().isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Enter a 10-digit mobile number and delivery address.')));return;}Navigator.pop(ctx);showDialog(context:context,builder:(dctx)=>AlertDialog(title:const Text('Demo checkout'),content:Text('Cart total: ₹$totalPrice\n\nThis is a UI demo. Connect a secure backend and OTP service to place real orders.'),actions:[TextButton(onPressed:(){Navigator.pop(dctx);setState(()=>cart.clear());},child:const Text('OK'))]));},child:const Text('Review order'))]))));
  }
  Widget profilePage()=>ListView(padding:const EdgeInsets.all(16),children:[const CircleAvatar(radius:38,backgroundColor:forest,child:Icon(Icons.person,color:Colors.white,size:40)),const SizedBox(height:12),const Center(child:Text('Welcome to Munna Dhaba',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold,color:forest))),const SizedBox(height:6),const Center(child:Text('Sign in with your mobile number')),const SizedBox(height:20),FilledButton.icon(onPressed:(){final phone=TextEditingController();showDialog(context:context,builder:(ctx)=>AlertDialog(title:const Text('Mobile login'),content:TextField(controller:phone,keyboardType:TextInputType.phone,maxLength:10,decoration:const InputDecoration(labelText:'10-digit mobile number')),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancel')),FilledButton(onPressed:(){Navigator.pop(ctx);ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('OTP requires Firebase Authentication or another OTP provider.')));},child:const Text('Continue'))]));},icon:const Icon(Icons.sms_outlined),label:const Text('Login with mobile')),const SizedBox(height:16),const Card(child:ListTile(leading:Icon(Icons.info_outline),title:Text('Restaurant information'),subtitle:Text('Address and contact details will be added once confirmed.')))]);
}
